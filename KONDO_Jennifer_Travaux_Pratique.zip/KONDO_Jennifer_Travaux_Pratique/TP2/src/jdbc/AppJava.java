package jdbc;

import java.sql.SQLException;

public class AppJava {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		Joueur joueur1 = new Joueur("KONDO", "jennifer", "KOJE0703", 12);
        Joueur joueur2 = new Joueur("BADJALIMBE", "Maxime", "BAMA2903", 5);
        Joueur joueur3 = new Joueur("KONDO", "sonia", "KOSO0703", 5);
        Joueur joueur4 = new Joueur("NAYO", "immaculée", "NAIM2903", 12);
        
        JoueurJdbc jjdc = new JoueurJdbc();

        jjdc.add(joueur1);
        jjdc.add(joueur2);
        jjdc.add(joueur3);
        jjdc.add(joueur4);

        jjdc.findAll();


	}

}
