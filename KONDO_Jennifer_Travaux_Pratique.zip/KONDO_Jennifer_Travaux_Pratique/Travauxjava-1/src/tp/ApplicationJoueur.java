package tp;

public class ApplicationJoueur {

	public static void main(String[] args) {
		 Joueur joueur1 = new Joueur("KONDO", "jennifer", "KOJE0703", 25);
	        Joueur joueur2 = new Joueur("BADJALIMBE", "Maxime", "BAMA2903", 90);
	        Joueur joueur3 = new Joueur("KONDO", "sonia", "KOSO0703", 30);
	        Joueur joueur4 = new Joueur("NAYO", "immaculée", "NAIM2903", 50);


	      
	}

}
