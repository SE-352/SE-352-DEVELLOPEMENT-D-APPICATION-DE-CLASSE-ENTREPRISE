package tg.ipnet.university.tp4;

import javax.persistence.Column;

import javax.persistence.MappedSuperclass;


@MappedSuperclass

public class Personne extends BaseEntity {
	
	 @Column(name="nom", length=60, nullable=false)
	    protected String nom;

	    @Column(name="prenom", length=60, nullable=false)
	    protected String prenom;

	    @Column(name="email", length=60)
	    protected String email;

	    public Personne()
	    {

	    }

		public Personne(String nom2, String prenom2, String email2) {
			
		}


}
