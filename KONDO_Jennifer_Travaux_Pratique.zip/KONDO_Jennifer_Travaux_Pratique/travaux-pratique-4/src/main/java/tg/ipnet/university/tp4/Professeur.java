package tg.ipnet.university.tp4;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "professeurs")

public class Professeur extends Personne{
	
	
	 @Column(name = "grade", nullable = true)
	    private String grade;

	    
	    @ManyToMany()
	   
	    private Set<Cours> cours;

	  
	    @ManyToMany()
	    
	    private Set<Departement> departements;

	    public Professeur() {

	    }

	    public Professeur(String nom, String prenom, String email, String grade) {
	        super();
	        this.grade = grade;
	    }

	    public String getGrade() {
	        return grade;
	    }

	    public void setGrade(String grade) {
	        this.grade = grade;
	    }

	    public Set<Cours> getCours() {
	        return cours;
	    }

	    public void setCours(Set<Cours> cours) {
	        this.cours = cours;
	    }

	    public Set<Departement> getDepartements() {
	        return departements;
	    }

	    public void setDepartements(Set<Departement> departements) {
	        this.departements = departements;
	    }


}
